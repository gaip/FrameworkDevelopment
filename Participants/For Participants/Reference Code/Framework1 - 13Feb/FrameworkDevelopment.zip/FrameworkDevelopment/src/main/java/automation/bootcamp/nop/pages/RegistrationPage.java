package automation.bootcamp.nop.pages;

public class RegistrationPage {
	
	private String url = "/register";

}
