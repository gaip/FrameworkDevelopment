package automation.bootcamp.nop.tests;

import org.testng.annotations.Test;

public class RegistrationPageTest {

	@Test
	public void registerStudent() {
		
		// launch browser
		
		// perform login
		
		// assert login
		
		// submit registration form
		
		// assert success message
		
		// verify reg form
		
		// assert reg form present or not
	}
}
