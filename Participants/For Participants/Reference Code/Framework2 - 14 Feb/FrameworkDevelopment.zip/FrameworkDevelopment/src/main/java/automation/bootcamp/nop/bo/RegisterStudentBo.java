package automation.bootcamp.nop.bo;

public class RegisterStudentBo {

}
