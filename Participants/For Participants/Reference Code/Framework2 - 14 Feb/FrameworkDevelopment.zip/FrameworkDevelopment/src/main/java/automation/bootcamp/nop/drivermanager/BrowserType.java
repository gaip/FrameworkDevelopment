package automation.bootcamp.nop.drivermanager;

public enum BrowserType {
	CHROME,
	FIREFOX
}
