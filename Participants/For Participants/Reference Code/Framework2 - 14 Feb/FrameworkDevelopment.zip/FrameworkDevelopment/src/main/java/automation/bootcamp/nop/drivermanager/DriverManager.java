package automation.bootcamp.nop.drivermanager;

import org.openqa.selenium.WebDriver;

public abstract class DriverManager {

	public abstract WebDriver getDriver();
}
