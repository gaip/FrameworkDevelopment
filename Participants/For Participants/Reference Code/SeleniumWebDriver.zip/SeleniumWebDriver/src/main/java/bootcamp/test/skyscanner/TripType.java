package bootcamp.test.skyscanner;

public enum TripType {
	RETURN, ONEWAY, MULTICITY
}
