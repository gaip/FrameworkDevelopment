package bootcamp.test;

import org.testng.annotations.Test;

public class BasicTest {

	@Test
	public void a() {
		System.out.println("Test a");
	}
}
