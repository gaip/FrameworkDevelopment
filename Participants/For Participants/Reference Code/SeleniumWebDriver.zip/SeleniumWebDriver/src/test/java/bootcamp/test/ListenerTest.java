package bootcamp.test;

import org.testng.annotations.Test;

public class ListenerTest {

	@Test
	public void test1() {
		System.out.println("Running test1");
	}
}
