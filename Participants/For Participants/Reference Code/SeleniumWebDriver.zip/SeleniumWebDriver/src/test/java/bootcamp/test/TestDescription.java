package bootcamp.test;

import org.testng.annotations.Test;

public class TestDescription {

	@Test(description = "sample test to test parameter")
	public void a() {

	}
}
