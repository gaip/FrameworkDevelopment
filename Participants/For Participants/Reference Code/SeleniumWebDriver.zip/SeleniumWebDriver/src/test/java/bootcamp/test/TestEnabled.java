package bootcamp.test;

import org.testng.annotations.Test;

public class TestEnabled {
	@Test(enabled = false)
	public void b() {

	}
}
